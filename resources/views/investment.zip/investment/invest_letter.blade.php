<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Print Offer Letter</title>
    <link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('assets/dist/css/AdminLTE.min.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 0mm;
            /* this affects the margin in the printer settings */
        }

        html {
            background-color: #FFFFFF;
            margin: 0px;
            /* this affects the margin on the html before sending to printer */
        }

        body {
            margin: 10mm 10mm 10mm 10mm;
            /* margin you want for the content */
        }
    </style>
    <style>
        thead {
            display: table-header-group;
        }

        .table {
            border-collapse: collapse !important;
        }

        .table td,
        .table th {
            background-color: #fff !important;
            font-size: 20px;
        }

        .table-bordered th,
        .table-bordered td {}

        th {
            text-align: left;
        }

        .table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 20px;
        }

        .table>thead>tr>th,
        .table>tbody>tr>th,
        .table>tfoot>tr>th,
        .table>thead>tr>td,
        .table>tbody>tr>td,
        .table>tfoot>tr>td {
            padding: 8px;
            line-height: 1.42857143;
            vertical-align: top;
        }

        .table>thead>tr>th {
            vertical-align: bottom;
        }

        .table>caption+thead>tr:first-child>th,
        .table>colgroup+thead>tr:first-child>th,
        .table>thead:first-child>tr:first-child>th,
        .table>caption+thead>tr:first-child>td,
        .table>colgroup+thead>tr:first-child>td,
        .table>thead:first-child>tr:first-child>td {
            border-top: 0;
        }

        .table>tbody+tbody {}

        .table .table {
            background-color: #fff;
        }

        .table-condensed>thead>tr>th,
        .table-condensed>tbody>tr>th,
        .table-condensed>tfoot>tr>th,
        .table-condensed>thead>tr>td,
        .table-condensed>tbody>tr>td,
        .table-condensed>tfoot>tr>td {
            padding: 5px;
        }

        .table-bordered {
            border: 1px solid #ddd;
        }

        .table-bordered>thead>tr>th,
        .table-bordered>tbody>tr>th,
        .table-bordered>tfoot>tr>th,
        .table-bordered>thead>tr>td,
        .table-bordered>tbody>tr>td,
        .table-bordered>tfoot>tr>td {
            border: 1px solid #ddd;
        }

        .table-bordered>thead>tr>th,
        .table-bordered>thead>tr>td {
            border-bottom-width: 2px;
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }

        .table-hover>tbody>tr:hover {
            background-color: #f5f5f5;
        }

        table col[class*="col-"] {
            position: static;
            display: table-column;
            float: none;
        }

        table td[class*="col-"],
        table th[class*="col-"] {
            position: static;
            display: table-cell;
            float: none;
        }

        .table>thead>tr>td.active,
        .table>tbody>tr>td.active,
        .table>tfoot>tr>td.active,
        .table>thead>tr>th.active,
        .table>tbody>tr>th.active,
        .table>tfoot>tr>th.active,
        .table>thead>tr.active>td,
        .table>tbody>tr.active>td,
        .table>tfoot>tr.active>td,
        .table>thead>tr.active>th,
        .table>tbody>tr.active>th,
        .table>tfoot>tr.active>th {
            background-color: #f5f5f5;
        }

        .table-hover>tbody>tr>td.active:hover,
        .table-hover>tbody>tr>th.active:hover,
        .table-hover>tbody>tr.active:hover>td,
        .table-hover>tbody>tr:hover>.active,
        .table-hover>tbody>tr.active:hover>th {
            background-color: #e8e8e8;
        }

        .table>thead>tr>td.success,
        .table>tbody>tr>td.success,
        .table>tfoot>tr>td.success,
        .table>thead>tr>th.success,
        .table>tbody>tr>th.success,
        .table>tfoot>tr>th.success,
        .table>thead>tr.success>td,
        .table>tbody>tr.success>td,
        .table>tfoot>tr.success>td,
        .table>thead>tr.success>th,
        .table>tbody>tr.success>th,
        .table>tfoot>tr.success>th {
            background-color: #dff0d8;
        }

        .table-hover>tbody>tr>td.success:hover,
        .table-hover>tbody>tr>th.success:hover,
        .table-hover>tbody>tr.success:hover>td,
        .table-hover>tbody>tr:hover>.success,
        .table-hover>tbody>tr.success:hover>th {
            background-color: #d0e9c6;
        }

        .table>thead>tr>td.info,
        .table>tbody>tr>td.info,
        .table>tfoot>tr>td.info,
        .table>thead>tr>th.info,
        .table>tbody>tr>th.info,
        .table>tfoot>tr>th.info,
        .table>thead>tr.info>td,
        .table>tbody>tr.info>td,
        .table>tfoot>tr.info>td,
        .table>thead>tr.info>th,
        .table>tbody>tr.info>th,
        .table>tfoot>tr.info>th {
            background-color: #d9edf7;
        }

        .table-hover>tbody>tr>td.info:hover,
        .table-hover>tbody>tr>th.info:hover,
        .table-hover>tbody>tr.info:hover>td,
        .table-hover>tbody>tr:hover>.info,
        .table-hover>tbody>tr.info:hover>th {
            background-color: #c4e3f3;
        }

        .table>thead>tr>td.warning,
        .table>tbody>tr>td.warning,
        .table>tfoot>tr>td.warning,
        .table>thead>tr>th.warning,
        .table>tbody>tr>th.warning,
        .table>tfoot>tr>th.warning,
        .table>thead>tr.warning>td,
        .table>tbody>tr.warning>td,
        .table>tfoot>tr.warning>td,
        .table>thead>tr.warning>th,
        .table>tbody>tr.warning>th,
        .table>tfoot>tr.warning>th {
            background-color: #fcf8e3;
        }

        .table-hover>tbody>tr>td.warning:hover,
        .table-hover>tbody>tr>th.warning:hover,
        .table-hover>tbody>tr.warning:hover>td,
        .table-hover>tbody>tr:hover>.warning,
        .table-hover>tbody>tr.warning:hover>th {
            background-color: #faf2cc;
        }

        .table>thead>tr>td.danger,
        .table>tbody>tr>td.danger,
        .table>tfoot>tr>td.danger,
        .table>thead>tr>th.danger,
        .table>tbody>tr>th.danger,
        .table>tfoot>tr>th.danger,
        .table>thead>tr.danger>td,
        .table>tbody>tr.danger>td,
        .table>tfoot>tr.danger>td,
        .table>thead>tr.danger>th,
        .table>tbody>tr.danger>th,
        .table>tfoot>tr.danger>th {
            background-color: #f2dede;
        }

        .table-hover>tbody>tr>td.danger:hover,
        .table-hover>tbody>tr>th.danger:hover,
        .table-hover>tbody>tr.danger:hover>td,
        .table-hover>tbody>tr:hover>.danger,
        .table-hover>tbody>tr.danger:hover>th {
            background-color: #ebcccc;
        }

        .table-responsive {
            min-height: .01%;
            overflow-x: auto;
        }

        .row {
            margin-right: -15px;
            margin-left: -15px;
            clear: both;
        }

        .col-md-6 {
            width: 50%;
            position: relative;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px;
        }

        .well {
            min-height: 20px;
            padding: 19px;
            margin-bottom: 20px;
            background-color: #f5f5f5;
            border: 1px solid #e3e3e3;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
        }

        tbody:before,
        tbody:after {
            display: none;
        }

        .text-left {
            text-align: left;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-justify {
            text-align: justify;
        }

        .pull-right {
            float: right !important;
        }
    </style>
</head>

<body>
    <?php
    $getsetvalue = new \App\Models\Setting();
    $currcy = DB::table('exchangerates')->select('currency_symbol')->where('id', $fd->customer->exchangerate_id)->first();
    ?>
    @inject('getloan', 'App\Http\Controllers\InvestmentController')
    <div>

        <div class="row invoice-info" style="width:80%; margin:auto;">
            <div class="container" style="text-align:justify;margin-top:240px !important;font-size:22px">
                <div style="margin-left: 15px;font-style:normal">
                    <strong>Generated Date: </strong> &nbsp; &nbsp; &nbsp; {{ date('d-m-Y') }}<br>
                    <strong> Customer Name: </strong>&nbsp;&nbsp;&nbsp;
                    <strong>{{ strtoupper($fd->customer->first_name . ' ' . $fd->customer->last_name) }}</strong><br>
                    <strong>Address :</strong> &nbsp; &nbsp; &nbsp;{{ ucwords($fd->customer->residential_address) }}
                    <br>
                    <strong>Investment Code:</strong> &nbsp; &nbsp; &nbsp; {{ $fd->fixed_deposit_code }}<br>

                </div>
                <br>
                <div style="text-align:justify;margin-left:15px">
                    Dear Sir/Ma,
                </div>
            </div>
            <br>
            <br>
            <h3 class="text-center" style="font-size:22px">
                <strong> CERTIFICATE OF INVESTMENT </strong>
            </h3>
            <p style="font-size:22px">In line with your consideration, an investment has been created in your favour
                under the following terms and conditions:</p>

            <div
                style="text-align:justify;width: 1000px;margin-top:5px;margin-left: auto;margin-right: auto;padding:0px 2px;text-transform: capitalize; font-size:22px">

                <table class="table table-condensed table-striped table-sm">
                    <tbody>

                        <?php
                        $wtx = ($getloan->investment_total_interest($fd->id) / 100) * $fd->withholding_tax;
                        $payable = $getloan->investment_total_interest($fd->id) - $wtx;
                        
                        $whtintr = ($getloan->investment_permonth($fd->id) / 100) * $fd->withholding_tax;
                        $towhtintr = $getloan->investment_permonth($fd->id) - $whtintr;
                        
                        $dur = 0;
                        if ($fd->duration_type == 'year') {
                            $dur = $fd->duration * 12;
                        } elseif ($fd->duration_type == 'month') {
                            $dur = $fd->duration;
                        }
                        ?>

                        <tr>
                            <td style="font-weight:bold">Type of Investment: </td>
                            <td align="left" style="font-weight:bold;">{{ $fd->fixed_deposit_product->name }}</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Amount Invested: </td>
                            <td align="left" style="font-weight:bold;">
                                {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                {{ number_format($fd->principal, 2) }}</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Tenor: </td>
                            <td align="left" style="font-weight:bold;">{{ $dur * 30 }} Day(s)</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Effective Date: </td>
                            <td align="left" style="font-weight:bold;">
                                {{ date('d M, Y', strtotime($fd->release_date)) }}</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Maturity Date: </td>
                            <td align="left" style="font-weight:bold;">
                                {{ date('d M, Y', strtotime($fd->maturity_date)) }}</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Interest Rate: </td>
                            <td align="left" style="font-weight:bold;">{{ number_format($fd->interest_rate, 2) }}% /
                                {{ $fd->interest_period }}</td>
                        </tr>

                        <tr>
                            <td style="font-weight:bold">Interest Method: </td>
                            <td align="left" style="font-weight:bold;">
                                {{ ucwords(str_replace('_', ' ', $fd->interest_method)) }}</td>
                        </tr>

                        @if ($fd->enable_withholding_tax == '1')
                            <tr>
                                <td style="font-weight:bold">Expected Monthly Interest: </td>
                                <td align="left" style="font-weight:bold;">
                                    {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                    {{ number_format($towhtintr, 2) }}</td>
                            </tr>
                        @else
                            <tr>
                                <td style="font-weight:bold">Expected Monthly Interest: </td>
                                <td align="left" style="font-weight:bold;">
                                    {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                    {{ number_format($getloan->investment_permonth($fd->id), 2) }}</td>
                            </tr>
                        @endif

                        <tr>
                            <td style="font-weight:bold">Expected Interest (
                                {{ $fd->duration . ' ' . $fd->duration_type . '(s)' }} ): </td>
                            <td align="left" style="font-weight:bold;">
                                {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                {{ number_format($getloan->investment_total_interest($fd->id), 2) }}</td>
                        </tr>

                        @if ($fd->enable_withholding_tax == '1')
                            <tr>
                                <td style="font-weight:bold">Withholding Tax ({{ $fd->withholding_tax }}%): </td>
                                <td align="left" style="font-weight:bold;">
                                    {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                    {{ number_format($wtx, 2) }}
                                </td>
                            </tr>
                        @endif


                        @if ($fd->enable_withholding_tax == '1')
                            <tr>
                                <td style="font-weight:bold">Total Interest Payable: </td>
                                <td align="left" style="font-weight:bold;">
                                    {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                    {{ number_format($payable, 2) }}</td>
                            </tr>
                        @else
                            <tr>
                                <td style="font-weight:bold">Total Interest Payable: </td>
                                <td align="left" style="font-weight:bold;">
                                    {{ !empty($currcy) ? $currcy->currency_symbol : 'N' }}
                                    {{ number_format($getloan->investment_total_interest($fd->id), 2) }}</td>
                            </tr>
                        @endif
                        </tr>
                    </tbody>
                </table>
            </div>

            <div
                style="text-align:justify;width: 100%;margin-top:0.5px;margin-left: auto;margin-right: auto;padding:0 15px; font-size: 22px;word-wrap: break-word;">
                <p>The interest due on the consideration is as stated above and
                    {{ $fd->interest_method == 'upfront' ? 'this has been credited to your account' : 'this will be credited to your account upon maturity' }}.
                </p>
                <p>Please note that we have the obligation to rollover the principal at prevailing market interest rate
                    if we do not receive your instruction on how to treat the proceeds within three (3) working days
                    before maturity.</p>
                <p>Note that penalty charge for termination before maturity is
                    {{ $getsetvalue->getsettingskey('fdcharge') }}% flat on accrued interest.</p>
                <p>Thank you for your patronage, we look forward to strengthening the mutual and beneficial relationship
                    existing between your good self and our organization.</p>
                <p>Please acknowledge the receipt of this letter on the attached copy.</p>

                <p>Yours Faithfully, <br>
                    {{ $fd->customer->section == 'rich green masters' ? ucwords($getsetvalue->getsettingskey('company_name')) : ($fd->customer->section == 'rich green capital' ? 'RichGreen Masters Capital Limited' : 'Asset Matrix MFB') }}
                </p><br><br><br>



                <div style="display:flex; justify-content:space-between; margin-top:40px;">

                    <div style="text-align:center; width:300px;">
                        <img src="{{ $signatoryOne }}" width="180" style="background:transparent;">

                        <div style="border-bottom:2px solid #000; width:220px; margin:5px auto 10px auto;"></div>

                        <strong>Ayotunde Yusuf</strong>
                        <br>
                        Authorised Signatory
                    </div>

                    <div style="text-align:center; width:300px;">
                        <img src="{{ $signatoryTwo }}" width="180" style="background:transparent;">

                        <div style="border-bottom:2px solid #000; width:220px; margin:5px auto 10px auto;"></div>

                        <strong>Abiodun Shoyomi</strong>
                        <br>
                        Authorised Signatory
                    </div>

                </div>


            </div>

        </div>

        <script>
            window.onload = function() {
                window.print();
            }
        </script>
</body>

</html>
